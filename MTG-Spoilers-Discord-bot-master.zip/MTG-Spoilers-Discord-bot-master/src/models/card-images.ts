export interface ICardImages {
    small: string;
    normal: string;
    large: string;
    png: string;
    border_crop: string;
    art_crop: string;
}